-- BASE DE DATOS H.A.M.---------------------------------------------------------------
-- DROP DATABASE def_ext_ham; -- comentar si es la primera vez creando la bd

CREATE DATABASE IF NOT EXISTS def_ext_ham;
Use def_ext_ham;

CREATE TABLE persona(
	id INT NOT NULL AUTO_INCREMENT,
	nombres VARCHAR(60) NOT NULL,
	p_apellido VARCHAR(40) NOT NULL,
	s_apellido VARCHAR(40),
	carnet VARCHAR(15) NOT NULL UNIQUE,
	telefono VARCHAR(15) NOT NULL,
	PRIMARY KEY (id)
)Engine = innodb;

CREATE TABLE rol(
	id INT NOT NULL,
	nombre VARCHAR(20) NOT NULL,
	descripcion VARCHAR(255) NOT NULL,
	PRIMARY KEY (id)
)Engine = innodb;

CREATE TABLE usuario (
    id INT NOT NULL AUTO_INCREMENT,
    usuario VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(128) NOT NULL, -- longitud de 64 SHA2('password123', 256) 
	estado CHAR(1) NOT NULL CHECK (estado IN ('1', '2')),  -- 1:activo , 2:inactivo 
	id_persona INT NOT NULL,
    id_rol INT NOT NULL,
    FOREIGN KEY (id_persona) REFERENCES persona(id),
    FOREIGN KEY (id_rol) REFERENCES rol(id),
	PRIMARY KEY (id)
)Engine = innodb;

CREATE TABLE unidad_vecinal(
	id INT NOT NULL AUTO_INCREMENT,
	numero_uv VARCHAR(6) NOT NULL UNIQUE,
	PRIMARY KEY (id)
)Engine = innodb;

CREATE TABLE unidad_educativa(
	id INT NOT NULL AUTO_INCREMENT,
	nombre_unidad VARCHAR(50) NOT NULL,
	estado CHAR(1) NOT NULL CHECK (estado IN ('1', '2')),-- 1:activo , 2:inactivo 
	direccion VARCHAR(128),
	telefono VARCHAR(15) NOT NULL,
	id_unidad_vecinal INT NOT NULL,
	PRIMARY KEY (id),
	FOREIGN KEY (id_unidad_vecinal) REFERENCES unidad_vecinal(id)
)Engine = innodb;

CREATE TABLE tipo_mantenimiento(
	id INT NOT NULL,
	nombre_mantenimiento VARCHAR(50) NOT NULL,
	descripcion VARCHAR(255) NOT NULL,
	estado CHAR(1) NOT NULL CHECK (estado IN ('1', '2')),-- 1:activo , 2:inactivo 
	tarifa_estimada DECIMAL(10,2) NOT NULL,
	PRIMARY KEY (id)
)Engine = innodb;


CREATE TABLE solicitud (
    id INT NOT NULL AUTO_INCREMENT,
	descripcion VARCHAR(50) NOT NULL,
	fecha_registro DATE NOT NULL,
	estado CHAR(1) NOT NULL CHECK (estado IN ('1', '2', '3')), -- 1:pendiente , 2:atendido ,3:descartado
	id_tipo_mantenimiento INT NOT NULL,
	id_unidad_educativa INT NOT NULL,
	PRIMARY KEY (id),
	FOREIGN KEY (id_tipo_mantenimiento) REFERENCES tipo_mantenimiento(id),
	FOREIGN KEY (id_unidad_educativa) REFERENCES unidad_educativa(id)
)Engine = InnoDB;


CREATE TABLE empresa_contratada(
	id INT NOT NULL AUTO_INCREMENT,
	nombre_empresa VARCHAR(50) NOT NULL,
	nit VARCHAR(20) NOT NULL UNIQUE,
	direccion VARCHAR(128),
	estado CHAR(1) NOT NULL CHECK (estado IN ('1', '2')),
	PRIMARY KEY (id)
)Engine = innodb;

CREATE TABLE empresa_mantenimiento(
	id_tipo_mantenimiento INT NOT NULL,
	id_empresa_contratada INT NOT NULL,
	estado CHAR(1) NOT NULL CHECK (estado IN ('1', '2')), -- 1:disponible , 2:no disponible
	PRIMARY KEY (id_tipo_mantenimiento,id_empresa_contratada),
	FOREIGN KEY (id_tipo_mantenimiento) REFERENCES tipo_mantenimiento(id),
	FOREIGN KEY (id_empresa_contratada) REFERENCES empresa_contratada(id)
)Engine = innodb;

CREATE TABLE atendimiento(
	id INT NOT NULL AUTO_INCREMENT,
	fecha_registro DATE NOT NULL,
	fecha_inicializacion DATE NOT NULL,
	fecha_finalizacion DATE NOT NULL CHECK (fecha_finalizacion >= DATE(fecha_inicializacion)), -- no se puede ingresar una fecha_finalizacion menor que la fecha_inicializacion 
	tarifa_servicio_empresa DECIMAL(10,2) NOT NULL,
	tarifa_materiales DECIMAL(10,2) NOT NULL,
	estado CHAR(1) NOT NULL CHECK (estado IN ('1', '2','3','4')),  -- 1:por empezar , 2:en proceso ,3:finalizado,4:cancelado
	estado_pago CHAR(1) NOT NULL CHECK (estado IN ('1', '2','3')), -- 1:impago , 2:pagado ,3:pago_pendiente
	id_empresa_contratada INT NOT NULL,
	id_solicitud INT NOT NULL,
	PRIMARY KEY (id),
	FOREIGN KEY (id_empresa_contratada) REFERENCES empresa_contratada(id),
	FOREIGN KEY (id_solicitud) REFERENCES solicitud(id)
)Engine = InnoDB;

CREATE TABLE atendimiento_cancelado(
	id INT NOT NULL AUTO_INCREMENT,
	fecha_registro DATE NOT NULL,
	motivo VARCHAR(128),
	id_atendimiento INT NOT NULL,
	PRIMARY KEY (id),
	FOREIGN KEY (id_atendimiento) REFERENCES atendimiento(id)
)Engine = innodb;


CREATE TABLE pago_mantenimiento(
	id INT NOT NULL AUTO_INCREMENT,
	total_gasto DECIMAL(10,2) NOT NULL,
	fecha_registro DATETIME NOT NULL,
	adjunto_pago VARCHAR(255),
	observacion VARCHAR(255),
	id_atendimiento INT NOT NULL,
	PRIMARY KEY (id),
	FOREIGN KEY (id_atendimiento) REFERENCES atendimiento(id)
)Engine = InnoDB;

/* =========== Bitacora =========== */
CREATE TABLE bitacora (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
	nombre_usuario VARCHAR(50) NOT NULL,
	id_rol INT NOT NULL,
    tabla VARCHAR(50) NOT NULL,
    operacion VARCHAR(10) NOT NULL,
    fecha_registro DATETIME NOT NULL,
    detalles TEXT NOT NULL
)Engine = InnoDB;


