/*
==================================================
	PROCEDIMIENTOS ALMACENADOS - H.A.M.
==================================================
*/

-- AUTENTICACION DE USUARIO --
DELIMITER //
CREATE PROCEDURE autenticacion_usuario(
    IN p_usuario VARCHAR(50),
    IN p_password VARCHAR(50)
)
BEGIN	
    SELECT u.usuario as nombre_usuario,u.id as id_usuario, r.id as id_rol 
    FROM usuario u
	JOIN rol r ON u.id_rol=r.id
	WHERE u.usuario = p_usuario
    AND u.password = SHA2(p_password, 256) 
    AND u.estado = '1';
END //
DELIMITER ;


-- REGISTRAR SOLICITUD  --
DELIMITER //
CREATE PROCEDURE registrar_solicitud(
    IN p_descripcion VARCHAR(50),
    IN p_fecha_registro DATE,
    IN p_id_tipo_mantenimiento INT,
    IN p_id_unidad_educativa INT
)
BEGIN
    -- Verificar si el tipo de mantenimiento tiene un estado de '1' (activo)
    DECLARE v_estado_tipo_mantenimiento CHAR(1);
    SELECT estado INTO v_estado_tipo_mantenimiento
    FROM tipo_mantenimiento
    WHERE id = p_id_tipo_mantenimiento;
    
    IF v_estado_tipo_mantenimiento = '1' THEN
        -- Insertar la solicitud
        INSERT INTO solicitud (descripcion, fecha_registro, estado, id_tipo_mantenimiento, id_unidad_educativa)
        VALUES (p_descripcion, p_fecha_registro, '1', p_id_tipo_mantenimiento, p_id_unidad_educativa);
    ELSE
        -- Lanzar un error si el tipo de mantenimiento no está activo
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'El tipo de mantenimiento seleccionado no está activo.';
    END IF;
END //
DELIMITER ;


-- REGISTRAR ATENDIMIENTO --
DELIMITER //
CREATE PROCEDURE registrar_atendimiento(
    IN p_fecha_inicializacion DATE,
    IN p_fecha_finalizacion DATE,
    IN p_tarifa_servicio_empresa DECIMAL(10,2),
    IN p_tarifa_materiales DECIMAL(10,2),
    IN p_id_empresa_contratada INT,
    IN p_id_solicitud INT
)
BEGIN
    DECLARE v_estado_empresa CHAR(1);
    DECLARE v_estado_solicitud CHAR(1);

    -- Verificar el estado de la empresa contratada
    SELECT estado INTO v_estado_empresa
    FROM empresa_contratada
    WHERE id = p_id_empresa_contratada;
	
    -- Verificar el estado de la solicitud
    SELECT estado INTO v_estado_solicitud
    FROM solicitud
    WHERE id = p_id_solicitud;

    IF v_estado_empresa = '1' AND v_estado_solicitud='1' THEN
        -- Insertar el atendimiento
        INSERT INTO atendimiento (fecha_registro, fecha_inicializacion, fecha_finalizacion, tarifa_servicio_empresa, tarifa_materiales, estado, id_empresa_contratada, id_solicitud)
        VALUES (NOW(), p_fecha_inicializacion, p_fecha_finalizacion, p_tarifa_servicio_empresa, p_tarifa_materiales, '1', p_id_empresa_contratada, p_id_solicitud);
    ELSE
        -- Lanzar un error si la empresa no está activa o la solicitud no es atendible
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Error al registrar Atendimiento';
    END IF;
END //
DELIMITER ;


-- REGISTRAR PAGO --
DELIMITER //
CREATE PROCEDURE registrar_pago_mantenimiento(
    IN p_total_gasto DECIMAL(10,2) ,
	IN p_adjunto_pago VARCHAR(255),
    IN p_observacion VARCHAR(255),
    IN p_id_atendimiento INT
)
BEGIN
    INSERT INTO pago_mantenimiento (total_gasto, fecha_registro, observacion,adjunto_pago, id_atendimiento)
    VALUES (p_total_gasto, NOW(), p_observacion, p_adjunto_pago, p_id_atendimiento);
END //
DELIMITER ;


-- CANCELAR ATENDIMIENTO --
DELIMITER //
CREATE PROCEDURE cancelar_atendimiento(
    IN p_id_atendimiento INT,
    IN p_motivo VARCHAR(255)
)
BEGIN
    START TRANSACTION;
	
	 -- Insertar nuevo dato a atendimiento_cancelado
    INSERT INTO atendimiento_cancelado (id_atendimiento, motivo)
    VALUES (p_id_atendimiento, p_motivo);
	
    -- Actualizar estado del atendimiento a  'cancelado'
    UPDATE atendimiento
    SET estado = '4',estado_pago='1'
    WHERE id = p_id_atendimiento;

    COMMIT;
END //
DELIMITER ;

-- REGISTRAR EN BITACORA
DELIMITER //
CREATE PROCEDURE registrar_bitacora (
    IN p_id_usuario INT,
    IN p_nombre_usuario VARCHAR(50),
    IN p_id_rol INT,
    IN p_tabla VARCHAR(50),
    IN p_operacion VARCHAR(10),
    IN p_detalles TEXT
)
BEGIN
    INSERT INTO bitacora (id_usuario, nombre_usuario, id_rol, tabla, operacion, fecha_registro, detalles)
    VALUES (p_id_usuario, p_nombre_usuario, p_id_rol, p_tabla, p_operacion, NOW(), p_detalles);
END//
DELIMITER ;


/*
==================================================
	TRIGGERS
==================================================
*/

-- Al registrar un atendimiento,la solicitud correspondiente cambia su estado a "2" (ATENDIDO)
DELIMITER //
CREATE TRIGGER actualizar_estado_solicitud
AFTER INSERT ON atendimiento
FOR EACH ROW
BEGIN
    UPDATE solicitud
    SET estado = '2'
    WHERE id = NEW.id_solicitud;
END//

-- TRIGGER DE BITACORA INSERT SOLICITUD
DELIMITER //
CREATE TRIGGER bitacora_insert_solicitud
AFTER INSERT ON solicitud
FOR EACH ROW
BEGIN
    DECLARE script TEXT;

    SET script = CONCAT(
        'INSERT INTO solicitud (descripcion, fecha_registro, estado, id_tipo_mantenimiento, id_unidad_educativa)
        VALUES (',
        QUOTE(NEW.descripcion), ', ',
        QUOTE(NEW.fecha_registro), ', ',
        QUOTE(NEW.estado), ', ',
        NEW.id_tipo_mantenimiento, ', ',
        NEW.id_unidad_educativa, ');'
    );
    CALL registrar_bitacora(@id_usuario, @nombre_usuario, @id_rol, 'solicitud', 'INSERT', script);

END//
DELIMITER ;

-- TRIGGER DE BITACORA UPDATE SOLICITUD
DELIMITER //
CREATE TRIGGER bitacora_update_solicitud
AFTER UPDATE ON solicitud
FOR EACH ROW
BEGIN
    DECLARE script TEXT;

    SET script = CONCAT(
        'UPDATE solicitud SET ',
        'descripcion = ', QUOTE(NEW.descripcion), ', ',
        'fecha_registro = ', QUOTE(NEW.fecha_registro), ', ',
        'estado = ', QUOTE(NEW.estado), ', ',
        'id_tipo_mantenimiento = ', NEW.id_tipo_mantenimiento, ', ',
        'id_unidad_educativa = ', NEW.id_unidad_educativa, 
        ' WHERE id = ', OLD.id, ';'
    );
    CALL registrar_bitacora(@id_usuario, @nombre_usuario, @id_rol, 'solicitud', 'UPDATE', script);
END//
DELIMITER ;

-- TRIGGER DE BITACORA INSERT ATENDIMIENTO
DELIMITER //
CREATE TRIGGER bitacora_insert_atendimiento
AFTER INSERT ON atendimiento
FOR EACH ROW
BEGIN
    DECLARE script TEXT;

    SET script = CONCAT(
        'INSERT INTO atendimiento (fecha_registro, fecha_inicializacion, fecha_finalizacion, tarifa_servicio_empresa, tarifa_materiales, estado, estado_pago, id_empresa_contratada, id_solicitud) VALUES (',
        QUOTE(NEW.fecha_registro), ', ',
        QUOTE(NEW.fecha_inicializacion), ', ',
        QUOTE(NEW.fecha_finalizacion), ', ',
        NEW.tarifa_servicio_empresa, ', ',
        NEW.tarifa_materiales, ', ',
        QUOTE(NEW.estado), ', ',
        QUOTE(NEW.estado_pago), ', ',
        NEW.id_empresa_contratada, ', ',
        NEW.id_solicitud, ');'
    );
    CALL registrar_bitacora(@id_usuario, @nombre_usuario, @id_rol, 'atendimiento', 'INSERT', script);
END//
DELIMITER ;

-- TRIGGER DE BITACORA UPDATE ATENDIMIENTO
DELIMITER //
CREATE TRIGGER bitacora_update_atendimiento
AFTER UPDATE ON atendimiento
FOR EACH ROW
BEGIN
    DECLARE script TEXT;

    SET script = CONCAT(
        'UPDATE atendimiento SET ',
        'fecha_registro = ', QUOTE(NEW.fecha_registro), ', ',
        'fecha_inicializacion = ', QUOTE(NEW.fecha_inicializacion), ', ',
        'fecha_finalizacion = ', QUOTE(NEW.fecha_finalizacion), ', ',
        'tarifa_servicio_empresa = ', NEW.tarifa_servicio_empresa, ', ',
        'tarifa_materiales = ', NEW.tarifa_materiales, ', ',
        'estado = ', QUOTE(NEW.estado), ', ',
        'estado_pago = ', QUOTE(NEW.estado_pago), ', ',
        'id_empresa_contratada = ', NEW.id_empresa_contratada, ', ',
        'id_solicitud = ', NEW.id_solicitud,
        ' WHERE id = ', OLD.id, ';'
    );
    CALL registrar_bitacora(@id_usuario, @nombre_usuario, @id_rol, 'atendimiento', 'UPDATE', script);
END//
DELIMITER ;


