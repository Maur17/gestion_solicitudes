-- Insertar datos en la tabla persona
INSERT INTO persona (nombres, p_apellido, s_apellido, carnet, telefono) VALUES
('Juan', 'Pérez', 'Sánchez', '12345678 SC', '555-1234'),
('María', 'Gómez', 'Fernández', '987654321 LP', '555-5678'),
('Pedro', 'Rodríguez', 'Jiménez', '756789123 SC', '555-9012');

-- Insertar datos en la tabla rol
INSERT INTO rol (id, nombre, descripcion) VALUES
(1, 'Administrador', 'Usuario con permisos de administración');

-- Insertar datos en la tabla usuario
INSERT INTO usuario (usuario, password, estado, id_persona, id_rol) VALUES
('admin', SHA2('password123', 256), '1', 1, 1);


-- Insertar datos en la tabla unidad_vecinal
INSERT INTO unidad_vecinal (numero_uv) VALUES
('UV-001'),
('UV-002'),
('UV-003'),
('UV-004'),
('UV-005'),
('UV-006'),
('UV-007'),
('UV-008'),
('UV-009'),
('UV-010');

-- Insertar datos en la tabla unidad_educativa

INSERT INTO unidad_educativa (nombre_unidad, estado, direccion, telefono, id_unidad_vecinal)
VALUES
  ('Colegio San Ignacio de Loyola', '1', 'Av. Banzer, Santa Cruz de la Sierra', '3412345', 1),
  ('Unidad Educativa Jesús María', '1', 'Calle Potosí, Santa Cruz de la Sierra', '3456789', 2),
  ('Colegio Alemán Santa Cruz', '1', 'Av. Cristo Redentor, Santa Cruz de la Sierra', '3423456', 3),
  ('Unidad Educativa Sagrado Corazón', '1', 'Calle Sucre, Santa Cruz de la Sierra', '3467890', 4),
  ('Colegio Salesiano Don Bosco', '1', 'Av. Irala, Santa Cruz de la Sierra', '3412678', 5),
  ('Colegio Salesiano San Pablo Bosco', '1', 'Av. Irala, Santa Cruz de la Sierra', '3672678', 2);
  
-- Insertar datos en la tabla tipo_mantenimiento
INSERT INTO tipo_mantenimiento (id, nombre_mantenimiento, descripcion, estado, tarifa_estimada) VALUES

(1, 'Pintado', 'Servicio de pintura para fachadas', '1', 1000.00),
(2, 'Remodelación de estructuras', 'Servicio de remodelación de estructuras', '1', 6000.00),
(3, 'Mantenimiento eléctrico', 'Servicio de mantenimiento eléctrico', '1', 3000.00),
(4, 'Jardinería', 'Servicio de mantenimiento de jardines', '1', 700.00),
(5, 'Mantenimiento de Instalaciones Sanitarias', 'Servicio de mantenimiento de instalaciones sanitarias', '1', 3000.00),
(6, 'Mantenimiento de Equipos y Mobiliario', 'Servicio de mantenimiento de equipos y mobiliario', '1', 4000.00),
(7, 'Mantenimiento de Instalaciones Deportivas', 'Servicio de mantenimiento de instalaciones deportivas', '1', 3500.00),
(8, 'Mantenimiento de iluminarias', 'Servicio de mantenimiento de iluminarias', '1', 2000.00);


-- Insertar datos en la tabla empresa_contratada
INSERT INTO empresa_contratada (nombre_empresa, nit, direccion, estado) VALUES
('Empresa A', '123456789', 'Calle 123, Zona A', '1'),
('Empresa B', '987654321', 'Avenida 456, Zona B', '1'),
('Empresa C', '456789123', 'Carrera 789, Zona C', '1'),
('Empresa D', '856732123', 'Carrera 339, Zona D', '1');

-- Insertar datos en la tabla empresa_mantenimiento
INSERT INTO empresa_mantenimiento (id_tipo_mantenimiento, id_empresa_contratada, estado) VALUES
(1, 1, '1'),
(2, 2, '1'),
(5, 2, '1'),
(6, 2, '1'),
(3, 3, '1'),
(4, 4, '1'),
(7, 4, '1');