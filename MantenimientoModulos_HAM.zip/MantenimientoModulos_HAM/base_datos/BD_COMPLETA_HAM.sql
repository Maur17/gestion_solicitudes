-- BASE DE DATOS H.A.M.---------------------------------------------------------------
-- DROP DATABASE def_ext_ham; -- comentar si es la primera vez creando la bd

CREATE DATABASE IF NOT EXISTS def_ext_ham;
Use def_ext_ham;

CREATE TABLE persona(
	id INT NOT NULL AUTO_INCREMENT,
	nombres VARCHAR(60) NOT NULL,
	p_apellido VARCHAR(40) NOT NULL,
	s_apellido VARCHAR(40),
	carnet VARCHAR(15) NOT NULL UNIQUE,
	telefono VARCHAR(15) NOT NULL,
	PRIMARY KEY (id)
)Engine = innodb;

CREATE TABLE rol(
	id INT NOT NULL,
	nombre VARCHAR(20) NOT NULL,
	descripcion VARCHAR(255) NOT NULL,
	PRIMARY KEY (id)
)Engine = innodb;

CREATE TABLE usuario (
    id INT NOT NULL AUTO_INCREMENT,
    usuario VARCHAR(50) NOT NULL UNIQUE,
    password VARCHAR(128) NOT NULL, -- longitud de 64 SHA2('password123', 256) 
	estado CHAR(1) NOT NULL CHECK (estado IN ('1', '2')),  -- 1:activo , 2:inactivo 
	id_persona INT NOT NULL,
    id_rol INT NOT NULL,
    FOREIGN KEY (id_persona) REFERENCES persona(id),
    FOREIGN KEY (id_rol) REFERENCES rol(id),
	PRIMARY KEY (id)
)Engine = innodb;

CREATE TABLE unidad_vecinal(
	id INT NOT NULL AUTO_INCREMENT,
	numero_uv VARCHAR(6) NOT NULL UNIQUE,
	PRIMARY KEY (id)
)Engine = innodb;

CREATE TABLE unidad_educativa(
	id INT NOT NULL AUTO_INCREMENT,
	nombre_unidad VARCHAR(50) NOT NULL,
	estado CHAR(1) NOT NULL CHECK (estado IN ('1', '2')),-- 1:activo , 2:inactivo 
	direccion VARCHAR(128),
	telefono VARCHAR(15) NOT NULL,
	id_unidad_vecinal INT NOT NULL,
	PRIMARY KEY (id),
	FOREIGN KEY (id_unidad_vecinal) REFERENCES unidad_vecinal(id)
)Engine = innodb;

CREATE TABLE tipo_mantenimiento(
	id INT NOT NULL,
	nombre_mantenimiento VARCHAR(50) NOT NULL,
	descripcion VARCHAR(255) NOT NULL,
	estado CHAR(1) NOT NULL CHECK (estado IN ('1', '2')),-- 1:activo , 2:inactivo 
	tarifa_estimada DECIMAL(10,2) NOT NULL,
	PRIMARY KEY (id)
)Engine = innodb;


CREATE TABLE solicitud (
    id INT NOT NULL AUTO_INCREMENT,
	descripcion VARCHAR(255) NOT NULL,
	fecha_registro DATE NOT NULL,
	estado CHAR(1) NOT NULL CHECK (estado IN ('1', '2', '3')), -- 1:pendiente , 2:atendido ,3:descartado
	id_tipo_mantenimiento INT NOT NULL,
	id_unidad_educativa INT NOT NULL,
	PRIMARY KEY (id),
	FOREIGN KEY (id_tipo_mantenimiento) REFERENCES tipo_mantenimiento(id),
	FOREIGN KEY (id_unidad_educativa) REFERENCES unidad_educativa(id)
)Engine = InnoDB;


CREATE TABLE empresa_contratada(
	id INT NOT NULL AUTO_INCREMENT,
	nombre_empresa VARCHAR(50) NOT NULL,
	nit VARCHAR(20) NOT NULL UNIQUE,
	direccion VARCHAR(128),
	estado CHAR(1) NOT NULL CHECK (estado IN ('1', '2')),
	PRIMARY KEY (id)
)Engine = innodb;

CREATE TABLE empresa_mantenimiento(
	id_tipo_mantenimiento INT NOT NULL,
	id_empresa_contratada INT NOT NULL,
	estado CHAR(1) NOT NULL CHECK (estado IN ('1', '2')), -- 1:disponible , 2:no disponible
	PRIMARY KEY (id_tipo_mantenimiento,id_empresa_contratada),
	FOREIGN KEY (id_tipo_mantenimiento) REFERENCES tipo_mantenimiento(id),
	FOREIGN KEY (id_empresa_contratada) REFERENCES empresa_contratada(id)
)Engine = innodb;

CREATE TABLE atendimiento(
	id INT NOT NULL AUTO_INCREMENT,
	fecha_registro DATE NOT NULL,
	fecha_inicializacion DATE NOT NULL,
	fecha_finalizacion DATE NOT NULL CHECK (fecha_finalizacion >= DATE(fecha_inicializacion)), -- no se puede ingresar una fecha_finalizacion menor que la fecha_inicializacion 
	tarifa_servicio_empresa DECIMAL(10,2) NOT NULL,
	tarifa_materiales DECIMAL(10,2) NOT NULL,
	estado CHAR(1) NOT NULL CHECK (estado IN ('1', '2','3','4')),  -- 1:por empezar , 2:en proceso ,3:finalizado,4:cancelado
	estado_pago CHAR(1) NOT NULL CHECK (estado_pago IN ('1', '2','3')), -- 1:impago , 2:pagado ,3:pago_pendiente
	id_empresa_contratada INT NOT NULL,
	id_solicitud INT NOT NULL,
	PRIMARY KEY (id),
	FOREIGN KEY (id_empresa_contratada) REFERENCES empresa_contratada(id),
	FOREIGN KEY (id_solicitud) REFERENCES solicitud(id)
)Engine = InnoDB;

CREATE TABLE atendimiento_cancelado(
	id INT NOT NULL AUTO_INCREMENT,
	fecha_registro DATE NOT NULL,
	motivo VARCHAR(128),
	id_atendimiento INT NOT NULL,
	PRIMARY KEY (id),
	FOREIGN KEY (id_atendimiento) REFERENCES atendimiento(id)
)Engine = innodb;


CREATE TABLE pago_mantenimiento(
	id INT NOT NULL AUTO_INCREMENT,
	total_gasto DECIMAL(10,2) NOT NULL,
	fecha_registro DATETIME NOT NULL,
	adjunto_pago VARCHAR(255),
	observacion VARCHAR(255),
	id_atendimiento INT NOT NULL,
	PRIMARY KEY (id),
	FOREIGN KEY (id_atendimiento) REFERENCES atendimiento(id)
)Engine = InnoDB;

/* =========== Bitacora =========== */
CREATE TABLE bitacora (
    id INT NOT NULL AUTO_INCREMENT PRIMARY KEY,
    id_usuario INT NOT NULL,
	nombre_usuario VARCHAR(50) NOT NULL,
	id_rol INT NOT NULL,
    tabla VARCHAR(50) NOT NULL,
    operacion VARCHAR(10) NOT NULL,
    fecha_registro DATETIME NOT NULL,
    detalles TEXT NOT NULL
)Engine = InnoDB;


/* ============================= INSERTS ============================= */
-- Insertar datos en la tabla persona
INSERT INTO persona (nombres, p_apellido, s_apellido, carnet, telefono) VALUES
('Juan', 'Pérez', 'Sánchez', '12345678 SC', '555-1234'),
('María', 'Gómez', 'Fernández', '987654321 LP', '555-5678'),
('Pedro', 'Rodríguez', 'Jiménez', '756789123 SC', '555-9012');

-- Insertar datos en la tabla rol
INSERT INTO rol (id, nombre, descripcion) VALUES
(1, 'Administrador', 'Usuario con permisos de administración');

-- Insertar datos en la tabla usuario
INSERT INTO usuario (usuario, password, estado, id_persona, id_rol) VALUES
('admin', SHA2('password123', 256), '1', 1, 1);


-- Insertar datos en la tabla unidad_vecinal
INSERT INTO unidad_vecinal (numero_uv) VALUES
('UV-001'),
('UV-002'),
('UV-003'),
('UV-004'),
('UV-005'),
('UV-006'),
('UV-007'),
('UV-008'),
('UV-009'),
('UV-010');

-- Insertar datos en la tabla unidad_educativa

INSERT INTO unidad_educativa (nombre_unidad, estado, direccion, telefono, id_unidad_vecinal)
VALUES
  ('Colegio San Ignacio de Loyola', '1', 'Av. Banzer, Santa Cruz de la Sierra', '3412345', 1),
  ('Unidad Educativa Jesús María', '1', 'Calle Potosí, Santa Cruz de la Sierra', '3456789', 2),
  ('Colegio Alemán Santa Cruz', '1', 'Av. Cristo Redentor, Santa Cruz de la Sierra', '3423456', 3),
  ('Unidad Educativa Sagrado Corazón', '1', 'Calle Sucre, Santa Cruz de la Sierra', '3467890', 4),
  ('Colegio Salesiano Don Bosco', '1', 'Av. Irala, Santa Cruz de la Sierra', '3412678', 5),
  ('Colegio Salesiano San Pablo Bosco', '1', 'Av. Irala, Santa Cruz de la Sierra', '3672678', 2),
  ('Colegio Nacional Florida', '1', 'Calle Florida, Santa Cruz de la Sierra', '3412345', 6),
  ('Unidad Educativa Nuevo Futuro', '1', 'Av. 2 de Agosto, Santa Cruz de la Sierra', '3456789', 2),
  ('Colegio La Salle', '1', 'Calle La Salle, Santa Cruz de la Sierra', '3423456', 3),
  ('Unidad Educativa Virgen de Cotoca', '1', 'Calle Cotoca, Santa Cruz de la Sierra', '3467890', 4),
  ('Colegio Simón Bolívar', '1', 'Calle Bolívar, Santa Cruz de la Sierra', '3412678', 8),
  ('Unidad Educativa Santa Cruz', '1', 'Av. San Martín, Santa Cruz de la Sierra', '3672678', 9),
  ('Colegio Fray Bartolomé de las Casas', '1', 'Calle Fray Bartolomé, Santa Cruz de la Sierra', '3487654', 3),
  ('Unidad Educativa San Juan Bautista', '1', 'Calle San Juan, Santa Cruz de la Sierra', '3498765', 10),
  ('Colegio Santa María', '1', 'Calle Santa María, Santa Cruz de la Sierra', '3509876', 5),
  ('Unidad Educativa Manuel Antonio Sáenz', '1', 'Av. Manuel Antonio, Santa Cruz de la Sierra', '3510987', 7);
  
-- Insertar datos en la tabla tipo_mantenimiento
INSERT INTO tipo_mantenimiento (id, nombre_mantenimiento, descripcion, estado, tarifa_estimada) VALUES

(1, 'Pintado', 'Servicio de pintura para fachadas', '1', 1000.00),
(2, 'Remodelación de estructuras', 'Servicio de remodelación de estructuras', '1', 6000.00),
(3, 'Mantenimiento eléctrico', 'Servicio de mantenimiento eléctrico', '1', 3000.00),
(4, 'Jardinería', 'Servicio de mantenimiento de jardines', '1', 700.00),
(5, 'Mantenimiento de Instalaciones Sanitarias', 'Servicio de mantenimiento de instalaciones sanitarias', '1', 3000.00),
(6, 'Mantenimiento de Equipos y Mobiliario', 'Servicio de mantenimiento de equipos y mobiliario', '1', 4000.00),
(7, 'Mantenimiento de Instalaciones Deportivas', 'Servicio de mantenimiento de instalaciones deportivas', '1', 3500.00),
(8, 'Mantenimiento de iluminarias', 'Servicio de mantenimiento de iluminarias', '1', 2000.00);


-- Insertar datos en la tabla empresa_contratada
INSERT INTO empresa_contratada (nombre_empresa, nit, direccion, estado) VALUES
('Empresa A', '123456789', 'Calle 123, Zona A', '1'),
('Empresa B', '987654321', 'Avenida 456, Zona B', '1'),
('Empresa C', '456789123', 'Carrera 789, Zona C', '1'),
('Empresa D', '856732123', 'Carrera 339, Zona D', '1');

-- Insertar datos en la tabla empresa_mantenimiento
INSERT INTO empresa_mantenimiento (id_tipo_mantenimiento, id_empresa_contratada, estado) VALUES
(1, 1, '1'),
(2, 2, '1'),
(5, 2, '1'),
(6, 2, '1'),
(3, 3, '1'),
(4, 4, '1'),
(7, 4, '1');

/*
==================================================
	PROCEDIMIENTOS ALMACENADOS - H.A.M.
==================================================
*/

-- AUTENTICACION DE USUARIO --
DELIMITER //
CREATE PROCEDURE autenticacion_usuario(
    IN p_usuario VARCHAR(50),
    IN p_password VARCHAR(50)
)
BEGIN	
    SELECT u.usuario as nombre_usuario, u.id as id_usuario, r.id as id_rol 
    FROM usuario u
	JOIN rol r ON u.id_rol=r.id
	WHERE u.usuario = p_usuario
    AND u.password = SHA2(p_password, 256) 
    AND u.estado = '1';
END //
DELIMITER ;


-- REGISTRAR SOLICITUD  --
DELIMITER //
CREATE PROCEDURE registrar_solicitud(
    IN p_descripcion VARCHAR(50),
    IN p_fecha_registro DATE,
    IN p_id_tipo_mantenimiento INT,
    IN p_id_unidad_educativa INT
)
BEGIN
    -- Verificar si el tipo de mantenimiento tiene un estado de '1' (activo)
    DECLARE v_estado_tipo_mantenimiento CHAR(1);
    SELECT estado INTO v_estado_tipo_mantenimiento
    FROM tipo_mantenimiento
    WHERE id = p_id_tipo_mantenimiento;
    
    IF v_estado_tipo_mantenimiento = '1' THEN
        -- Insertar la solicitud
        INSERT INTO solicitud (descripcion, fecha_registro, estado, id_tipo_mantenimiento, id_unidad_educativa)
        VALUES (p_descripcion, p_fecha_registro, '1', p_id_tipo_mantenimiento, p_id_unidad_educativa);
    ELSE
        -- Lanzar un error si el tipo de mantenimiento no está activo
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'El tipo de mantenimiento seleccionado no está activo.';
    END IF;
END //
DELIMITER ;


-- REGISTRAR ATENDIMIENTO --
DELIMITER //
CREATE PROCEDURE registrar_atendimiento(
    IN p_fecha_inicializacion DATE,
    IN p_fecha_finalizacion DATE,
    IN p_tarifa_servicio_empresa DECIMAL(10,2),
    IN p_tarifa_materiales DECIMAL(10,2),
    IN p_id_empresa_contratada INT,
    IN p_id_solicitud INT
)
BEGIN
    DECLARE v_estado_empresa CHAR(1);
    DECLARE v_estado_solicitud CHAR(1);
    DECLARE v_fecha_solicitud DATE;

    -- Verificar el estado de la empresa contratada
    SELECT estado INTO v_estado_empresa
    FROM empresa_contratada
    WHERE id = p_id_empresa_contratada;
	
    -- Verificar el estado de la solicitud
    SELECT estado, fecha_registro INTO v_estado_solicitud, v_fecha_solicitud
    FROM solicitud
    WHERE id = p_id_solicitud;

    IF v_estado_empresa = '1' AND v_estado_solicitud='1' AND p_fecha_inicializacion >= v_fecha_solicitud THEN
        -- Insertar el atendimiento
        INSERT INTO atendimiento (fecha_registro, fecha_inicializacion, fecha_finalizacion, tarifa_servicio_empresa, tarifa_materiales, estado, estado_pago, id_empresa_contratada, id_solicitud)
        VALUES (NOW(), p_fecha_inicializacion, p_fecha_finalizacion, p_tarifa_servicio_empresa, p_tarifa_materiales, '1', '3', p_id_empresa_contratada, p_id_solicitud);
    ELSE
        -- Lanzar un error si la empresa no está activa o la solicitud no es atendible
        SIGNAL SQLSTATE '45000'
        SET MESSAGE_TEXT = 'Error al registrar Atendimiento';
    END IF;
END //
DELIMITER ;


-- REGISTRAR PAGO --
DELIMITER //
CREATE PROCEDURE registrar_pago_mantenimiento(
    IN p_total_gasto DECIMAL(10,2) ,
	IN p_adjunto_pago VARCHAR(255),
    IN p_observacion VARCHAR(255),
    IN p_id_atendimiento INT
)
BEGIN
    DECLARE v_estado_pago_atendimiento CHAR(1);

    SELECT estado_pago INTO v_estado_pago_atendimiento
    FROM atendimiento WHERE id= p_id_atendimiento;

    IF v_estado_pago_atendimiento = '3' THEN
        INSERT INTO pago_mantenimiento (total_gasto, fecha_registro, observacion,adjunto_pago, id_atendimiento)
        VALUES (p_total_gasto, NOW(), p_observacion, p_adjunto_pago, p_id_atendimiento);

        UPDATE atendimiento SET estado_pago = '2' WHERE id = p_id_atendimiento;
    END IF;
END //
DELIMITER ;


-- CANCELAR ATENDIMIENTO --

DELIMITER //
CREATE PROCEDURE cancelar_atendimiento(
    IN p_id_atendimiento INT,
    IN p_motivo VARCHAR(255)
)
BEGIN

		DECLARE v_id_solicitud INT;

		-- Obtener el id_solicitud correspondiente
		SELECT id_solicitud INTO v_id_solicitud
		FROM atendimiento
		WHERE id = p_id_atendimiento;

		-- Actualizar estado del atendimiento a '4' (cancelado)
		UPDATE atendimiento 
		SET estado = '4'
		WHERE id = p_id_atendimiento;
	
    -- Verificar si se encontró un id_solicitud
		IF v_id_solicitud IS NOT NULL THEN
        UPDATE solicitud
        SET estado = '1'
        WHERE id = v_id_solicitud;

		END IF;
	 -- Insertar nuevo dato a atendimiento_cancelado
    INSERT INTO atendimiento_cancelado (fecha_registro,id_atendimiento, motivo)
    VALUES (NOW(),p_id_atendimiento, p_motivo);

END //
DELIMITER ;

-- REGISTRAR EN BITACORA
DELIMITER //
CREATE PROCEDURE registrar_bitacora (
    IN p_id_usuario INT,
    IN p_nombre_usuario VARCHAR(50),
    IN p_id_rol INT,
    IN p_tabla VARCHAR(50),
    IN p_operacion VARCHAR(10),
    IN p_detalles TEXT
)
BEGIN
    IF p_id_usuario THEN
        INSERT INTO bitacora (id_usuario, nombre_usuario, id_rol, tabla, operacion, fecha_registro, detalles)
        VALUES (p_id_usuario, p_nombre_usuario, p_id_rol, p_tabla, p_operacion, NOW(), p_detalles);
    ELSE
        INSERT INTO bitacora (id_usuario, nombre_usuario, id_rol, tabla, operacion, fecha_registro, detalles)
        VALUES (0, 'Sistema', 0, p_tabla, p_operacion, NOW(), p_detalles);
    END IF;
END//
DELIMITER ;


/*
==================================================
	TRIGGERS
==================================================
*/

-- Al registrar un atendimiento,la solicitud correspondiente cambia su estado a "2" (ATENDIDO)
DELIMITER //
CREATE TRIGGER actualizar_estado_solicitud
AFTER INSERT ON atendimiento
FOR EACH ROW
BEGIN
    UPDATE solicitud
    SET estado = '2'
    WHERE id = NEW.id_solicitud;
END//

-- TRIGGER DE BITACORA INSERT SOLICITUD
DELIMITER //
CREATE TRIGGER bitacora_insert_solicitud
AFTER INSERT ON solicitud
FOR EACH ROW
BEGIN
    DECLARE script TEXT;

    SET script = CONCAT(
        'INSERT INTO solicitud (descripcion, fecha_registro, estado, id_tipo_mantenimiento, id_unidad_educativa)
        VALUES (',
        QUOTE(NEW.descripcion), ', ',
        QUOTE(NEW.fecha_registro), ', ',
        QUOTE(NEW.estado), ', ',
        NEW.id_tipo_mantenimiento, ', ',
        NEW.id_unidad_educativa, ');'
    );
    CALL registrar_bitacora(@id_usuario, @nombre_usuario, @id_rol, 'solicitud', 'INSERT', script);

END//
DELIMITER ;

-- TRIGGER DE BITACORA UPDATE SOLICITUD
DELIMITER //
CREATE TRIGGER bitacora_update_solicitud
AFTER UPDATE ON solicitud
FOR EACH ROW
BEGIN
    DECLARE script TEXT;

    SET script = CONCAT(
        'UPDATE solicitud SET ',
        'descripcion = ', QUOTE(NEW.descripcion), ', ',
        'fecha_registro = ', QUOTE(NEW.fecha_registro), ', ',
        'estado = ', QUOTE(NEW.estado), ', ',
        'id_tipo_mantenimiento = ', NEW.id_tipo_mantenimiento, ', ',
        'id_unidad_educativa = ', NEW.id_unidad_educativa, 
        ' WHERE id = ', OLD.id, ';'
    );
    CALL registrar_bitacora(@id_usuario, @nombre_usuario, @id_rol, 'solicitud', 'UPDATE', script);
END//
DELIMITER ;

-- TRIGGER DE BITACORA INSERT ATENDIMIENTO
DELIMITER //
CREATE TRIGGER bitacora_insert_atendimiento
AFTER INSERT ON atendimiento
FOR EACH ROW
BEGIN
    DECLARE script TEXT;

    SET script = CONCAT(
        'INSERT INTO atendimiento (fecha_registro, fecha_inicializacion, fecha_finalizacion, tarifa_servicio_empresa, tarifa_materiales, estado, estado_pago, id_empresa_contratada, id_solicitud) VALUES (',
        QUOTE(NEW.fecha_registro), ', ',
        QUOTE(NEW.fecha_inicializacion), ', ',
        QUOTE(NEW.fecha_finalizacion), ', ',
        NEW.tarifa_servicio_empresa, ', ',
        NEW.tarifa_materiales, ', ',
        QUOTE(NEW.estado), ', ',
        QUOTE(NEW.estado_pago), ', ',
        NEW.id_empresa_contratada, ', ',
        NEW.id_solicitud, ');'
    );
    CALL registrar_bitacora(@id_usuario, @nombre_usuario, @id_rol, 'atendimiento', 'INSERT', script);
END//
DELIMITER ;

-- TRIGGER DE BITACORA UPDATE ATENDIMIENTO
DELIMITER //
CREATE TRIGGER bitacora_update_atendimiento
AFTER UPDATE ON atendimiento
FOR EACH ROW
BEGIN
    DECLARE script TEXT;

    SET script = CONCAT(
        'UPDATE atendimiento SET ',
        'fecha_registro = ', QUOTE(NEW.fecha_registro), ', ',
        'fecha_inicializacion = ', QUOTE(NEW.fecha_inicializacion), ', ',
        'fecha_finalizacion = ', QUOTE(NEW.fecha_finalizacion), ', ',
        'tarifa_servicio_empresa = ', NEW.tarifa_servicio_empresa, ', ',
        'tarifa_materiales = ', NEW.tarifa_materiales, ', ',
        'estado = ', QUOTE(NEW.estado), ', ',
        'estado_pago = ', QUOTE(NEW.estado_pago), ', ',
        'id_empresa_contratada = ', NEW.id_empresa_contratada, ', ',
        'id_solicitud = ', NEW.id_solicitud,
        ' WHERE id = ', OLD.id, ';'
    );
    CALL registrar_bitacora(@id_usuario, @nombre_usuario, @id_rol, 'atendimiento', 'UPDATE', script);
END//
DELIMITER ;



/* PROCEDIMIENTO PARA CREAR UN EVENTO EN MYSQL (DIARIO) */

-- SHOW VARIABLES LIKE 'event_scheduler';
-- SET GLOBAL event_scheduler = 'ON';

DELIMITER //
CREATE EVENT actualizar_estado_atendimiento
ON SCHEDULE EVERY 1 SECOND
STARTS CURRENT_TIMESTAMP
DO
BEGIN
    UPDATE atendimiento
    SET estado = '2'
    WHERE fecha_inicializacion <= CURDATE() AND estado = '1'; -- Solo cambiar si está "por empezar"
END//
DELIMITER ;



/* ============================ reportes ============================ */

-- Listado de solicitudes de mantenimiento pendientes (no se han empezado todavía)
SELECT s.id, s.descripcion, s.fecha_registro, 
    CASE 
    WHEN s.estado = '1' THEN 'Pendiente'
    WHEN s.estado = '2' THEN 'Atendido'
    WHEN s.estado = '3' THEN 'Descartado'
    END AS "estado",
tm.nombre_mantenimiento, ue.nombre_unidad
FROM solicitud s 
JOIN tipo_mantenimiento tm ON s.id_tipo_mantenimiento = tm.id
JOIN unidad_educativa ue ON s.id_unidad_educativa = ue.id
WHERE s.estado = '1' ;



-- CONSULTAS COMPLEJAS
SELECT 
    s.id AS ID_Solicitud,
    s.descripcion AS Descripcion_Solicitud,
    s.fecha_registro AS Fecha_Solicitud,
    ue.nombre_unidad AS Unidad_Educativa,
    tm.nombre_mantenimiento AS Tipo_Mantenimiento,
    e.nombre_empresa AS Empresa_Contratada,
    a.fecha_inicializacion AS Fecha_Inicio,
    a.fecha_finalizacion AS Fecha_Finalizacion,
    a.tarifa_servicio_empresa + a.tarifa_materiales AS Costo_Total,
    CASE 
        WHEN a.estado = '1' THEN 'Por Empezar'
        WHEN a.estado = '2' THEN 'En Proceso'
        WHEN a.estado = '3' THEN 'Finalizado'
        WHEN a.estado = '4' THEN 'Cancelado'
    END AS Estado_Atendimiento,
    CASE 
        WHEN a.estado_pago = '1' THEN 'Impago'
        WHEN a.estado_pago = '2' THEN 'Pagado'
        WHEN a.estado_pago = '3' THEN 'Pago Pendiente'
    END AS Estado_Pago,
    pm.total_gasto AS Monto_Pagado,
    pm.fecha_registro AS Fecha_Pago
FROM atendimiento a
JOIN solicitud s ON a.id_solicitud = s.id
JOIN unidad_educativa ue ON s.id_unidad_educativa = ue.id
JOIN tipo_mantenimiento tm ON s.id_tipo_mantenimiento = tm.id
JOIN empresa_contratada e ON a.id_empresa_contratada = e.id
LEFT JOIN pago_mantenimiento pm ON a.id = pm.id_atendimiento
ORDER BY s.fecha_registro DESC;



SELECT 
    s.id AS solicitud_id,
    s.descripcion AS solicitud_descripcion,
    s.fecha_registro AS fecha_solicitud,
    u.nombre_unidad AS unidad_educativa,
    ec.nombre_empresa AS empresa_contratada,
    a.fecha_registro AS fecha_atendimiento,
    a.fecha_inicializacion,
    a.fecha_finalizacion,
    a.tarifa_servicio_empresa,
    a.tarifa_materiales
FROM 
    solicitud s
JOIN 
    atendimiento a ON s.id = a.id_solicitud
JOIN 
    unidad_educativa u ON s.id_unidad_educativa = u.id
JOIN 
    empresa_contratada ec ON a.id_empresa_contratada = ec.id
WHERE 
    a.fecha_registro BETWEEN '2023-01-01' AND '2026-12-31'  -- Rango de fechas
    AND a.estado IN ('1', '2');  -- Solo mantenimientos "por empezar" o "en proceso"

