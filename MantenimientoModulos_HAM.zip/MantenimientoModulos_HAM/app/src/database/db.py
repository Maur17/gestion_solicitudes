from flask import session
from flask_mysqldb import MySQL    

def conectar_bd():
    try:
        conexion = MySQL().connect
        if 'sesion_abierta' in session:
            cursor = conexion.cursor()
            id_usuario=session['datos_usuario']['id_usuario']
            nombre_usuario = session['datos_usuario']['nombre_usuario']
            id_rol = session['datos_usuario']['id_rol']
            cursor.execute("SET @id_usuario = %s;", (id_usuario,))
            cursor.execute("SET @nombre_usuario = %s;", (nombre_usuario,))
            cursor.execute("SET @id_rol = %s;", (id_rol,))
            conexion.commit()
            return conexion
        else:
            return conexion
    except Exception as ex:
        # En caso de que algo falle en la conexion se envia esta exception
        # Si llega a fallar la conexion revisa las config de la BD
        raise Exception("Error al conectar con la base de datos", ex)
