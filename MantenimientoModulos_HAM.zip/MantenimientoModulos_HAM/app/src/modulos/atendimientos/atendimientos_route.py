from flask import Blueprint, jsonify, request, session, render_template, url_for, redirect, render_template
# Entidades
from entidades.atendimiento import Atendimiento, Atendimiento_Cancelado
# Modelos
from .atendimientos_model import AtendimientosModel

rt_atendimientos = Blueprint('atendimientos_bp', __name__, template_folder='templates')

'''
luego del registro de solicitud
    al entrar a la opcion atendimientos se cargaran todas las solicitudes
    se selecciona una solicitud con toda su informacion
    se selecciona la opcion "atender" para realizar el atendimiento
    se carga la vista de atendimiento,cargando el id de la solicitud seleccionada
    las empresas que se cargaran seran en base a la solicitud y los servicios que pide
    se selecciona la empresa que se encargara del mantenimiento
    se colocan las tarifas y fechas
    se registra el atendimiento
'''
@rt_atendimientos.route('/registrar_atendimiento_1', methods=['GET'])
def registrar_atendimiento_1():
    obt_solicitudes = AtendimientosModel.obt_solicitudes()
    return render_template("atendimiento_solicitud.html", tb_solicitudes=obt_solicitudes)

@rt_atendimientos.route('/obtener_empresas_mantenimiento/<int:id_tipo_mantenimiento>', methods=['GET'])
def obtener_empresas_mantenimiento(id_tipo_mantenimiento):
    resultado = AtendimientosModel.obtener_empresas_mantenimiento(id_tipo_mantenimiento)
    return jsonify(resultado)

@rt_atendimientos.route('/registrar_atendimiento_2/<int:id_soli>', methods=['GET','POST'])
def registrar_solicitudes(id_soli):
    if request.method == 'POST':
        data = request.form
        ent_atendimiento = Atendimiento(
            fecha_inicializacion = data.get('fecha_inicializacion'),
            fecha_finalizacion = data.get('fecha_finalizacion'),
            tarifa_servicio_empresa = data.get('tarifa_servicio_empresa'),
            tarifa_materiales = data.get('tarifa_materiales'),
            id_empresa_contratada = data.get('id_empresa_contratada'),
            id_solicitud = id_soli
        )
        resultado = AtendimientosModel.registrar_atendimiento(ent_atendimiento)
        if resultado[0]:
            respuesta = {'exito':True ,'titulo':'exito', 'mensaje':resultado[1],
                        'redireccion': url_for('atendimientos_bp.registrar_atendimiento_1')}
            return jsonify(respuesta)
        else:
            respuesta = {'exito':False ,'titulo':'error', 'mensaje':resultado[1]}
            return jsonify(respuesta)
    elif request.method == 'GET':
        tarifa_estimada_servicio = AtendimientosModel.obtener_tarifa_estimada_servicio(id_soli)
        obt_empresas_mantenimiento = AtendimientosModel.obtener_empresas_mantenimiento(id_soli)
        return render_template("registro_atendimiento_2.html", select_empresas=obt_empresas_mantenimiento, tarifa_estimada=tarifa_estimada_servicio )


@rt_atendimientos.route('/descartar_solicitud/<int:id_descartar>', methods=['POST'])
def descartar_solicitud(id_descartar):
        resultado=AtendimientosModel.descartar_solicitud(id_descartar)
        if resultado[0]:  # Si la operación fue exitosa
            return jsonify(resultado)
