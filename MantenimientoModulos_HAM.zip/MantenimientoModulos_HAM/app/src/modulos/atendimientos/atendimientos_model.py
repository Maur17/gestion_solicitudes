from database.db import conectar_bd
from utils.mensaje_error import formato_error
from utils.formato_tiempo import fecha

class AtendimientosModel():

    @classmethod
    def registrar_atendimiento(cls, ent):
        try:
            conn = conectar_bd()
            with conn.cursor() as cursor: 
                parametros = (ent.fecha_inicializacion, ent.fecha_finalizacion, ent.tarifa_servicio_empresa, 
                              ent.tarifa_materiales, ent.id_empresa_contratada, ent.id_solicitud)
                cursor.execute('call registrar_atendimiento(%s, %s, %s, %s, %s, %s)', parametros)
                conn.commit()
            conn.close()
            return [True, 'registro exitoso!']
        except Exception as ex:
            print(ex)
            error = formato_error(ex)
            return [False, error]

    @staticmethod
    def obt_solicitudes():
        conn = conectar_bd()
        resultado = [{'vacio': 'No hay datos'}]
        with conn.cursor() as cursor:
            cursor.execute("""SELECT s.id, s.descripcion, s.fecha_registro, tm.nombre_mantenimiento, tm.tarifa_estimada,
                ue.nombre_unidad ,ue.direccion,ue.telefono, tm.id
                FROM solicitud s 
                JOIN tipo_mantenimiento tm ON s.id_tipo_mantenimiento = tm.id
                JOIN unidad_educativa ue ON s.id_unidad_educativa = ue.id
                WHERE s.estado=1 
                ORDER BY s.fecha_registro ASC;""")
            resultado_sql = cursor.fetchall()
            if resultado_sql:
                datos_consulta=[]
                for fila in resultado_sql:
                    dato = {
                        'id': fila[0],
                        'descripcion': fila[1],
                        'fecha_registro': fecha(fila[2]),
                        'nombre_mantenimiento': fila[3],
                        'mantenimiento_tarifa_estimada': fila[4],
                        'nombre_unidad_educativa': fila[5],
                        'direccion': fila[6],
                        'telefono': fila[7],
                        'id_tipo_mantenimiento': fila[8]
                    }
                    datos_consulta.append(dato)
                resultado= datos_consulta
        conn.close()
        return resultado

    @staticmethod
    def obtener_empresas_mantenimiento(id_solicitud):
        conn = conectar_bd()
        resultado = [{'vacio': 'No hay empresas'}]
        with conn.cursor() as cursor:
            cursor.execute("""SELECT s.id_tipo_mantenimiento FROM solicitud s WHERE s.id = %s""", (id_solicitud,))
            id_tipo_mantenimiento = cursor.fetchone()
            cursor.execute("""SELECT ec.id, ec.nombre_empresa
                           FROM empresa_mantenimiento em
                           JOIN empresa_contratada ec ON em.id_empresa_contratada = ec.id
                           WHERE em.estado=1 AND em.id_tipo_mantenimiento=%s;
                           """,(id_tipo_mantenimiento,))
            resultado_sql = cursor.fetchall()
            if resultado_sql:
                datos_consulta=[]
                for fila in resultado_sql:
                    dato = {
                        'id': fila[0],
                        'nombre_empresa': fila[1]
                    }
                    datos_consulta.append(dato)
                resultado= datos_consulta
        conn.close()
        return resultado

    @staticmethod
    def obtener_tarifa_estimada_servicio(id_solicitud):
        conn = conectar_bd()
        with conn.cursor() as cursor:
            cursor.execute("""SELECT s.id_tipo_mantenimiento FROM solicitud s WHERE s.id = %s""", (id_solicitud,))
            id_tipo_mantenimiento = cursor.fetchone()
            cursor.execute("""SELECT tm.tarifa_estimada
                           FROM tipo_mantenimiento tm
                           WHERE tm.id=%s;
                           """,(id_tipo_mantenimiento,))
            tarifa_estimada_serv = cursor.fetchone()
        conn.close()
        return tarifa_estimada_serv[0]
    
    @staticmethod
    def descartar_solicitud(id_descartar):
        try:
            conn = conectar_bd()
            with conn.cursor() as cursor: 
                cursor.execute("""UPDATE solicitud s SET estado='3' WHERE s.id=%s """, (id_descartar,))
                conn.commit()
            conn.close()
            return [True, 'Descarte exitoso!']
        except Exception as ex:
            print(ex)
            error = formato_error(ex)
            return [False, error]
