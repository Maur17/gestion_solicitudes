from flask import Blueprint, jsonify, request, session, render_template, url_for, redirect, render_template
# Entidades
from entidades.solicitud import Solicitud
# Modelos
from .solicitudes_model import SolicitudesModel

rt_solicitudes = Blueprint('solicitudes_bp', __name__, template_folder='templates')

@rt_solicitudes.route('/registrar_solicitudes', methods=['GET','POST'])
def registrar_solicitudes():
    if request.method == 'POST':
        data = request.form
        descripcion = data.get('descripcion')
        fecha_registro = data.get('fecha_registro')
        id_tipo_mantenimiento = data.get('id_tipo_mantenimiento')
        id_unidad_educativa = data.get('id_unidad_educativa')
        ent_solicitud = Solicitud(descripcion=descripcion,fecha_registro=fecha_registro,id_tipo_mantenimiento=id_tipo_mantenimiento,id_unidad_educativa=id_unidad_educativa)
        resultado = SolicitudesModel.registrar_solicitudes(ent_solicitud)
        if resultado[0]:
            respuesta = {'exito':True ,'titulo':'exito', 'mensaje':resultado[1],
                        'redireccion': url_for('solicitudes_bp.registrar_solicitudes')}
            return jsonify(respuesta)
        else:
            respuesta = {'exito':False ,'titulo':'error', 'mensaje':resultado[1]}
            return jsonify(respuesta)
    elif request.method == 'GET':
        obt_tipo_mantenimiento = SolicitudesModel.obt_tipo_mantenimiento()
        obt_unidad_vecinal = SolicitudesModel.obt_unidad_vecinal() 
        #obt_unidad_educativa = SolicitudesModel.obt_unidad_educativa() ,selectUE=obt_unidad_educativa
        
        return render_template("registro_solicitud.html", selectTipMant = obt_tipo_mantenimiento,selectUV=obt_unidad_vecinal)


@rt_solicitudes.route('/obtener_unidad_educativa/<int:id>', methods=['GET'])
def obtener_unidad_educativa(id):
    obt_unidad_educativa = SolicitudesModel.obt_unidad_educativa(id)
    return jsonify(obt_unidad_educativa)

    