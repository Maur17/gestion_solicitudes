from database.db import conectar_bd
from utils.mensaje_error import formato_error

class SolicitudesModel():

    @classmethod
    def registrar_solicitudes(cls, soli):
        try:
            conn = conectar_bd()
            with conn.cursor() as cursor: 
                parametros = (soli.descripcion, soli.fecha_registro, soli.id_tipo_mantenimiento, soli.id_unidad_educativa)
                cursor.execute('call registrar_solicitud(%s, %s, %s, %s)', parametros)
                #res = cursor.fetchone()
                #if res and res[0] != None:
                #    return [False, res[0]]
                conn.commit()
            conn.close()
            return [True, 'registro exitoso!']
        except Exception as ex:
            print(ex)
            error = formato_error(ex)
            return [False, error]

    @staticmethod  
    def obt_tipo_mantenimiento():
        conn = conectar_bd()
        resultado = [{'id': '', 'nombre_mantenimiento': 'No hay datos'}]
        with conn.cursor() as cursor:
            cursor.execute("""SELECT t.id,t.nombre_mantenimiento FROM tipo_mantenimiento t WHERE estado=1;""")
            resultado_sql = cursor.fetchall()
            if resultado_sql:
                datos_consulta=[]
                for fila in resultado_sql:
                    dato = {
                        'id': fila[0],
                        'nombre_mantenimiento': fila[1]
                    }
                    datos_consulta.append(dato)
                resultado= datos_consulta
        conn.close()
        return resultado

    
    @staticmethod
    def obt_unidad_vecinal():
        conn = conectar_bd()
        resultado = [{'id': '', 'numero_uv': 'No hay datos'}]
        with conn.cursor() as cursor:
            cursor.execute("""SELECT  u.id,u.numero_uv FROM unidad_vecinal u;""")
            resultado_sql = cursor.fetchall()
            if resultado_sql:
                datos_consulta=[]
                for fila in resultado_sql:
                    dato = {
                        'id': fila[0],
                        'numero_uv': fila[1]
                    }
                    datos_consulta.append(dato)
                resultado= datos_consulta
        conn.close()
        return resultado

    
    @staticmethod
    def obt_unidad_educativa(id_uv):
        conn = conectar_bd()
        resultado = [{'id': '', 'nombre_unidad': 'No hay datos'}]
        with conn.cursor() as cursor:
            cursor.execute("""SELECT  u.id,u.nombre_unidad FROM unidad_educativa u WHERE estado=1 AND u.id_unidad_vecinal=%s;""",(id_uv,))
            resultado_sql = cursor.fetchall()
            if resultado_sql:
                datos_consulta=[]
                for fila in resultado_sql:
                    dato = {
                        'id': fila[0],
                        'nombre_unidad': fila[1]
                    }
                    datos_consulta.append(dato)
                resultado= datos_consulta
        conn.close()
        return resultado