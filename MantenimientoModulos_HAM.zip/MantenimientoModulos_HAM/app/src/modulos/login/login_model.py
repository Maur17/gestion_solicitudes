from flask import session
from database.db import conectar_bd
from utils.mensaje_error import formato_error

class SesionUsuario():

    @classmethod
    def verificar_usuario(cls, usu):
        try:
            respuesta = [False, 'creedenciales incorrectas!']
            conn = conectar_bd()
            with conn.cursor() as cursor:
                #traer los parametros en la variable
                parametros = (usu.usuario, usu.password)
                cursor.execute('call autenticacion_usuario(%s, %s)', parametros) #  u.usuario as nombre_usuario, u.id as id_usuario, r.id as id_rol 
                resultado_sql = cursor.fetchone() # fetchone(): traer un solo dato, fetchall(): traer multiples datos
                if resultado_sql:
                    SesionUsuario.guardar_sesion(resultado_sql)
                    respuesta = [True, 'credenciales correctas!']
            conn.close()
            return respuesta
        except Exception as ex:
            print(ex)
            error = formato_error(ex)
            return [False, error]
    
    def guardar_sesion(datos):
        session['sesion_abierta'] = True
        #---------------
        session['datos_usuario'] = {
            'nombre_usuario': datos[0],
            'id_usuario': datos[1],
            'id_rol': datos[2]
        }
       
    def cerrar_sesion():
        session.clear()


