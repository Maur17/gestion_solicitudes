from flask import Blueprint, jsonify, request, session, render_template, url_for, redirect
# Entidades
from entidades.pago_mantenimiento import Pago_Mantenimiento
# Modelos
from .pago_mantenimiento_model import PagoMantenimientoModel

rt_pago_mantenimiento = Blueprint('pago_mantenimiento_bp', __name__, template_folder='templates')

@rt_pago_mantenimiento.route('/ver_atendimientos', methods=['GET'])
def ver_atendimientos():
    obt_atendimientos = PagoMantenimientoModel.obt_atendimientos()
    return render_template("pago_mantenimiento.html", tb_atendimientos=obt_atendimientos)


@rt_pago_mantenimiento.route('/finalizar_mantenimiento/<int:id_finalizar>', methods=['POST'])
def finalizar_mantenimiento(id_finalizar):
    resultado=PagoMantenimientoModel.finalizar_atendimiento(id_finalizar)
    if resultado[0]:
        respuesta = {'exito':True ,'titulo':'exito', 'mensaje':resultado[1],
                        'redireccion': url_for('pago_mantenimiento_bp.ver_atendimientos')}
        return jsonify(respuesta)
    else:
        respuesta = {'exito':False ,'titulo':'error', 'mensaje':resultado[1]}
        return jsonify(respuesta)


@rt_pago_mantenimiento.route('/cancelar_mantenimiento/<int:id_cancelar>', methods=['POST'])
def cancelar_mantenimiento(id_cancelar):
# Obtener datos del cuerpo de la solicitud
    data = request.get_json()
    motivo = data.get('motivo', '') 

    resultado=PagoMantenimientoModel.cancelar_atendimiento(id_cancelar,motivo)
    if resultado[0]:
        respuesta = {'exito':True ,'titulo':'exito', 'mensaje':resultado[1],
                        'redireccion': url_for('pago_mantenimiento_bp.ver_atendimientos')}
        return jsonify(respuesta)
    else:
        respuesta = {'exito':False ,'titulo':'error', 'mensaje':resultado[1]}
        return jsonify(respuesta)


@rt_pago_mantenimiento.route('/registrar_pago_mantenimiento/<int:id_atendimiento>/<float:total_gasto>', methods=['GET','POST'])
def registrar_pago_mantenimiento(id_atendimiento, total_gasto):
    if request.method == 'POST':
        data = request.form
        total_gasto = total_gasto
        adjunto_pago = request.files['adjunto_pago']
        observacion = data.get('observacion')
        id_atendimiento = id_atendimiento
        
        ruta_img_db = ""
        if adjunto_pago: 
            ruta_img_db='imgs_subidas/adjunto_'+str(id_atendimiento)+ adjunto_pago.filename
            
            ruta_img = 'static/imgs_subidas/adjunto_'+str(id_atendimiento)+ adjunto_pago.filename
            adjunto_pago.save(ruta_img)  # Guardar archivo en la carpeta de subida



        ent_pago_mantenimiento = Pago_Mantenimiento(total_gasto=total_gasto,adjunto_pago=ruta_img_db,observacion=observacion,id_atendimiento=id_atendimiento)
       
        resultado = PagoMantenimientoModel.registrar_pago(ent_pago_mantenimiento)
        if resultado[0]:
            respuesta = {'exito':True ,'titulo':'exito', 'mensaje':resultado[1],
                        'redireccion': url_for('pago_mantenimiento_bp.ver_atendimientos')}
            return jsonify(respuesta)
        else:
            respuesta = {'exito':False ,'titulo':'error', 'mensaje':resultado[1]}
            return jsonify(respuesta)
    elif request.method == 'GET':
        return render_template("registrar_pago.html",total_gasto = total_gasto)


