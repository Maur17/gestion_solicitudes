from database.db import conectar_bd
from utils.mensaje_error import formato_error
from utils.formato_tiempo import fecha

class PagoMantenimientoModel():

    @classmethod
    def registrar_pago(cls, atend):
        try:
            conn = conectar_bd()
            with conn.cursor() as cursor: 
                parametros = (atend.total_gasto, atend.adjunto_pago, atend.observacion, atend.id_atendimiento )
                cursor.execute('call registrar_pago_mantenimiento(%s, %s, %s, %s)', parametros)
                conn.commit()
            conn.close()
            return [True, 'registro exitoso!']
        except Exception as ex:
            print(ex)
            error = formato_error(ex)

            return [False, error]


    @staticmethod
    def obt_atendimientos():
        conn = conectar_bd()
        resultado = [{'vacio': 'No hay datos'}]
        with conn.cursor() as cursor:
            cursor.execute("""SELECT 
                a.id,
                a.fecha_registro,
                a.fecha_inicializacion,
                a.fecha_finalizacion,
                a.tarifa_servicio_empresa,
                a.tarifa_materiales,
                (a.tarifa_servicio_empresa + a.tarifa_materiales) AS tarifa_total,
                
                CASE 
                    WHEN a.estado = '1' THEN 'Por Empezar'
                    WHEN a.estado = '2' THEN 'En Proceso'
                    WHEN a.estado = '3' THEN 'Finalizado'
                    WHEN a.estado = '4' THEN 'Cancelado'
                    ELSE 'Desconocido'
                END AS "Estado",

                CASE 
                    WHEN a.estado_pago = '1' THEN 'Impago'
                    WHEN a.estado_pago = '2' THEN 'Pagado'
                    WHEN a.estado_pago = '3' THEN 'Pago Pendiente'
                    ELSE 'N/E'
                END AS "Estado de Pago",

                e.nombre_empresa AS "Empresa Contratada",  -- Aquí se muestra el nombre en vez del ID
                a.id_solicitud

            FROM atendimiento a
            JOIN empresa_contratada e ON a.id_empresa_contratada = e.id
            ORDER BY a.fecha_registro ASC;
            """)
            resultado_sql = cursor.fetchall()
            if resultado_sql:
                datos_consulta=[]
                for fila in resultado_sql:
                    dato = {
                        'id': fila[0],
                        'fecha_registro':fecha(fila[1]),
                        'fecha_inicializacion':fecha(fila[2]),
                        'fecha_finalizacion':fecha(fila[3]),
                        'tarifa_servicio_empresa': fila[4],
                        'tarifa_materiales': fila[5],
                        'tarifa_total': fila[6],
                        'estado': fila[7],
                        'estado_pago': fila[8],
                        'empresa_contratada': fila[9],
                        'id_solicitud': fila[10]
                    }
                    datos_consulta.append(dato)
                resultado= datos_consulta
        conn.close()
        return resultado

    @staticmethod
    def finalizar_atendimiento(id_finalizar):
        try:
            conn = conectar_bd()
            with conn.cursor() as cursor: 
                cursor.execute("""UPDATE atendimiento a SET estado='3' WHERE a.id=%s;""", (id_finalizar,))
                conn.commit()
            conn.close()
            return [True, 'Proyecto Finalizado!']
        except Exception as ex:
            print(ex)
            error = formato_error(ex)
            return [False, error]
        
    @staticmethod
    def cancelar_atendimiento(id_cancelar,motivo):
        try:
            conn = conectar_bd()
            with conn.cursor() as cursor: 
                cursor.execute('call cancelar_atendimiento(%s, %s)', (id_cancelar,motivo))
                conn.commit()
            conn.close()
            return [True, 'Cancelado exitoso!']
        except Exception as ex:
            print(ex)
            error = formato_error(ex)
            return [False, error]