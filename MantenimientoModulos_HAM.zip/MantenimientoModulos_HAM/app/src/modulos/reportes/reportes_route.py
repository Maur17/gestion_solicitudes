from flask import Blueprint, jsonify, request, render_template, url_for,send_file

# Modelos
from .reportes_model import ReportesModel

#imports nuevos
import openpyxl
from io import BytesIO

rt_reporte = Blueprint('reporte_bp', __name__, template_folder='templates')

@rt_reporte.route('/', methods=['GET'])
def principal_reporte():
    obt_reporte_pagos = ReportesModel.pagos_realizados()
    return render_template("reportes.html", tb_reporte_pagos=obt_reporte_pagos)



@rt_reporte.route('/descargar_excel_solicitudes_pendientes', methods=['GET'])
def descargar_excel():
    # Obtén los datos de las solicitudes pendientes
    datos = ReportesModel.solicitudes_pendientes()
    if not datos or 'vacio' in datos[0]:
        return jsonify({"error": "No hay datos disponibles para generar el archivo Excel"}), 404

    # Crear un archivo Excel en memoria
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "Solicitudes Pendientes"

    # Agregar encabezados
    encabezados = ['ID', 'Descripción', 'Fecha Registro', 'Estado', 'Nombre Mantenimiento', 'Nombre Unidad']
    sheet.append(encabezados)

    # Agregar datos al archivo
    for dato in datos:
        sheet.append([
            dato['id'],
            dato['descripcion'],
            dato['fecha_registro'],  # Convertir fecha a string
            dato['estado'],
            dato['nombre_mantenimiento'],
            dato['nombre_unidad']
        ])

    # Guardar el archivo Excel en memoria
    output = BytesIO()
    workbook.save(output)
    output.seek(0)

    # Enviar el archivo como respuesta para descargar
    return send_file(
        output,
        as_attachment=True,
        download_name="solicitudes_pendientes.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )




@rt_reporte.route('/descargar_excel_atendimientos_proceso', methods=['GET'])
def descargar_excel_2():
    # Obtén los datos de las solicitudes pendientes
    datos = ReportesModel.atendimientos_proceso()
    if not datos or 'vacio' in datos[0]:
        return jsonify({"error": "No hay datos disponibles para generar el archivo Excel"}), 404

    # Crear un archivo Excel en memoria
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "Atendimientos en Proceso"

    # Agregar encabezados
    encabezados = ['ID', 'fecha_registro', 'fecha_inicializacion', 'tarifa_servicio_empresa', 'tarifa_materiales', 'Estado','Estado de Pago','nombre_empresa']
    sheet.append(encabezados)

    # Agregar datos al archivo
    for dato in datos:
        sheet.append([
            dato['id'],
            dato['fecha_registro'],
            dato['fecha_inicializacion'],  # Convertir fecha a string
            dato['fecha_finalizacion'],
            dato['tarifa_servicio_empresa'],
            dato['tarifa_materiales'],
            dato['Estado'],
            dato['Estado de Pago'],
            dato['nombre_empresa']

        ])

    # Guardar el archivo Excel en memoria
    output = BytesIO()
    workbook.save(output)
    output.seek(0)

    # Enviar el archivo como respuesta para descargar
    return send_file(
        output,
        as_attachment=True,
        download_name="atendimientos_en_proceso.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )


@rt_reporte.route('/descargar_excel_costo_mantenimiento', methods=['GET'])
def descargar_excel_costo_mantenimiento():
    # Obtén los datos de costo total de mantenimiento por unidad educativa
    datos = ReportesModel.costo_ue_finalizada_uv()
    if not datos or 'vacio' in datos[0]:
        return jsonify({"error": "No hay datos disponibles para generar el archivo Excel"}), 404

    # Crear un archivo Excel en memoria
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "Costo Mantenimiento por Unidad Educativa"

    # Agregar encabezados
    encabezados = ['Id','Nombre Unidad Educativa', 'Número UV', 'Costo Total de Mantenimiento']
    sheet.append(encabezados)

    # Agregar datos al archivo
    for dato in datos:
        sheet.append([
            dato['Id'],
            dato['Nombre_Unidad_Educativa'],
            dato['Numero_UV'],
            dato['Costo_Total_de_Mantenimiento']
        ])

    # Guardar el archivo Excel en memoria
    output = BytesIO()
    workbook.save(output)
    output.seek(0)

    # Enviar el archivo como respuesta para descargar
    return send_file(
        output,
        as_attachment=True,
        download_name="costo_mantenimiento_unidad_educativa.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )

@rt_reporte.route('/descargar_excel_costo_mantenimiento_por_tipo', methods=['GET'])
def descargar_excel_costo_mantenimiento_por_tipo():
    # Obtén los datos de costo total de mantenimiento por tipo de mantenimiento y año
    datos = ReportesModel.gastos_tipomant_gestion()
    if not datos or 'vacio' in datos[0]:
        return jsonify({"error": "No hay datos disponibles para generar el archivo Excel"}), 404

    # Crear un archivo Excel en memoria
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "Costo Mantenimiento por Tipo"

    # Agregar encabezados
    encabezados = ['Tipo de Mantenimiento', 'Año', 'Costo Total']
    sheet.append(encabezados)

    # Agregar datos al archivo
    for dato in datos:
        sheet.append([
            dato['Tipo_mantenimiento'],
            dato['Año'],
            dato['Costo_total']
        ])

    # Guardar el archivo Excel en memoria
    output = BytesIO()
    workbook.save(output)
    output.seek(0)

    # Enviar el archivo como respuesta para descargar
    return send_file(
        output,
        as_attachment=True,
        download_name="costo_mantenimiento_por_tipo.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )



@rt_reporte.route('/descargar_excel_pagos_realizados', methods=['GET'])
def descargar_excel_pagos_realizados():
    datos = ReportesModel.excel_pagos_realizados()
    if not datos or 'vacio' in datos[0]:
        return jsonify({"error": "No hay datos disponibles para generar el archivo Excel"}), 404

    # Crear un archivo Excel en memoria
    workbook = openpyxl.Workbook()
    sheet = workbook.active
    sheet.title = "Pagos"

    # Agregar encabezados
    encabezados = ['id','total_gasto', 'fecha_registro','observacion','tipo_mantenimiento','unidad_educativa']
    sheet.append(encabezados)

    # Agregar datos al archivo
    for dato in datos:
        sheet.append([
            dato['pago_id'],
            dato['total_gasto'],
            dato['fecha_registro'],
            dato['observacion'],
            dato['tipo_mantenimiento'],
            dato['unidad_educativa']

        ])

    # Guardar el archivo Excel en memoria
    output = BytesIO()
    workbook.save(output)
    output.seek(0)

    # Enviar el archivo como respuesta para descargar
    return send_file(
        output,
        as_attachment=True,
        download_name="pagos.xlsx",
        mimetype="application/vnd.openxmlformats-officedocument.spreadsheetml.sheet"
    )



