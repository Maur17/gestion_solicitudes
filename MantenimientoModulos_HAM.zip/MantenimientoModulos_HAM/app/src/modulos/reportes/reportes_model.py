from database.db import conectar_bd
from utils.mensaje_error import formato_error
from utils.formato_tiempo import fecha

class ReportesModel():
    
    @staticmethod  
    def solicitudes_pendientes():
        conn = conectar_bd()
        resultado = [{'vacio': 'No hay datos'}]
        with conn.cursor() as cursor:
            cursor.execute("""SELECT s.id, s.descripcion, s.fecha_registro, 
                CASE 
                WHEN s.estado = '1' THEN 'Pendiente'
                WHEN s.estado = '2' THEN 'Atendido'
                WHEN s.estado = '3' THEN 'Descartado'
                END AS "estado",
            tm.nombre_mantenimiento, ue.nombre_unidad
            FROM solicitud s 
            JOIN tipo_mantenimiento tm ON s.id_tipo_mantenimiento = tm.id
            JOIN unidad_educativa ue ON s.id_unidad_educativa = ue.id
            WHERE s.estado = '1' ;""")
            resultado_sql = cursor.fetchall()
            if resultado_sql:
                datos_consulta=[]
                for fila in resultado_sql:
                    dato = {
                        'id': fila[0],
                        'descripcion': fila[1],
                        'fecha_registro': fecha(fila[2]),
                        'estado': fila[3],
                        'nombre_mantenimiento': fila[4],
                        'nombre_unidad': fila[5]
                    }
                    datos_consulta.append(dato)
                resultado= datos_consulta
        conn.close()
        return resultado
    
    



    @staticmethod  
    def atendimientos_proceso():
        conn = conectar_bd()
        resultado = [{'vacio': 'No hay datos'}]
        with conn.cursor() as cursor:
            cursor.execute("""
                SELECT 
                a.id,
                a.fecha_registro,
                a.fecha_inicializacion,
                a.fecha_finalizacion,
                a.tarifa_servicio_empresa,
                a.tarifa_materiales,
                CASE 
                    WHEN a.estado = '1' THEN 'Por Empezar'
                    WHEN a.estado = '2' THEN 'En Proceso'
                    WHEN a.estado = '3' THEN 'Finalizado'
                    WHEN a.estado = '4' THEN 'Cancelado'
                    ELSE 'Desconocido'
                END AS "Estado",

                CASE 
                    WHEN a.estado_pago = '1' THEN 'Impago'
                    WHEN a.estado_pago = '2' THEN 'Pagado'
                    WHEN a.estado_pago = '3' THEN 'Pago Pendiente'
                    ELSE 'N/E'
                END AS "Estado de Pago",

                e.nombre_empresa AS "Empresa Contratada",  -- Aquí se muestra el nombre en vez del ID
                a.id_solicitud

            FROM atendimiento a
            JOIN empresa_contratada e ON a.id_empresa_contratada = e.id
            WHERE a.estado='2'
            ORDER BY a.fecha_registro ASC;
                           """)
            resultado_sql = cursor.fetchall()
            if resultado_sql:
                datos_consulta=[]
                for fila in resultado_sql:
                    dato = {
                        'id': fila[0],
                        'fecha_registro': fecha(fila[1]),
                        'fecha_inicializacion': fecha(fila[2]),
                        'fecha_finalizacion': fecha(fila[3]),
                        'tarifa_servicio_empresa': fila[4],
                        'tarifa_materiales': fila[5],
                        'Estado': fila[6],
                        'Estado de Pago': fila[7],
                        'nombre_empresa': fila[8]

                    }
                    datos_consulta.append(dato)
                resultado= datos_consulta
        conn.close()
        return resultado
    
    @staticmethod  
    def costo_ue_finalizada_uv():
        conn = conectar_bd()
        resultado = [{'vacio': 'No hay datos'}]
        with conn.cursor() as cursor:
            cursor.execute("""
                        SELECT 
                            ue.id AS Id,
                            ue.nombre_unidad AS Nombre_Unidad_Educativa,
                            uv.numero_uv AS Numero_UV,
                            SUM(pm.total_gasto) AS Costo_Total_de_Mantenimiento
                        FROM 
                            unidad_educativa ue
                        JOIN 
                            solicitud s ON ue.id = s.id_unidad_educativa
                        JOIN 
                            atendimiento a ON s.id = a.id_solicitud
                        JOIN 
                            pago_mantenimiento pm ON a.id = pm.id_atendimiento
                        JOIN 
                            unidad_vecinal uv ON ue.id_unidad_vecinal = uv.id
                        GROUP BY 
                            ue.id, uv.numero_uv
                        ORDER BY 
                            uv.numero_uv ASC;
                           """)
            resultado_sql = cursor.fetchall()
            if resultado_sql:
                datos_consulta=[]
                for fila in resultado_sql:
                    dato = {
                        'Id': fila[0],
                        'Nombre_Unidad_Educativa': fila[1],
                        'Numero_UV': fila[2],
                        'Costo_Total_de_Mantenimiento':fila[3]
                        
                    }
                    datos_consulta.append(dato)
                resultado= datos_consulta
        conn.close()
        return resultado
    


    @staticmethod  
    def gastos_tipomant_gestion():
        conn = conectar_bd()
        resultado = [{'vacio': 'No hay datos'}]
        with conn.cursor() as cursor:
            cursor.execute("""

                SELECT 
                tm.nombre_mantenimiento AS Tipo_mantenimiento,
                YEAR(a.fecha_finalizacion) AS Año,
                SUM(pm.total_gasto) AS Costo_total
            FROM 
                atendimiento a
            JOIN 
                solicitud s ON a.id_solicitud = s.id
            JOIN 
                tipo_mantenimiento tm ON s.id_tipo_mantenimiento = tm.id
            JOIN 
                pago_mantenimiento pm ON a.id = pm.id_atendimiento
            WHERE 
                a.estado = '3' -- Solo incluir atendimientos finalizados
            GROUP BY 
                tm.id, YEAR(a.fecha_finalizacion)
            ORDER BY 
                año DESC;
                           """)
            resultado_sql = cursor.fetchall()
            if resultado_sql:
                datos_consulta=[]
                for fila in resultado_sql:
                    dato = {
                        'Tipo_mantenimiento': fila[0],
                        'Año': fila[1],
                        'Costo_total':fila[2]
                        
                    }
                    datos_consulta.append(dato)
                resultado= datos_consulta
        conn.close()
        return resultado
    

    @staticmethod  
    def pagos_realizados():
        conn = conectar_bd()
        resultado = [{'vacio': 'No hay datos'}]
        with conn.cursor() as cursor:
            cursor.execute("""
                                SELECT 
                                pm.id AS pago_id,
                                pm.total_gasto,
                                pm.fecha_registro,
                                pm.adjunto_pago,
                                pm.observacion,
                                tm.nombre_mantenimiento AS tipo_mantenimiento,
                                ue.nombre_unidad AS unidad_educativa
                            FROM pago_mantenimiento pm
                            JOIN atendimiento a ON pm.id_atendimiento = a.id
                            JOIN solicitud s ON a.id_solicitud = s.id
                            JOIN tipo_mantenimiento tm ON s.id_tipo_mantenimiento = tm.id
                            JOIN unidad_educativa ue ON s.id_unidad_educativa = ue.id
                            ORDER BY pm.fecha_registro ASC;
                           """)
            resultado_sql = cursor.fetchall()
            if resultado_sql:
                datos_consulta=[]
                for fila in resultado_sql:
                    dato = {
                        'pago_id': fila[0],
                        'total_gasto': fila[1],
                        'fecha_registro':fecha(fila[2]),
                        'adjunto_pago':fila[3],
                        'observacion':fila[4],
                        'tipo_mantenimiento':fila[5],
                        'unidad_educativa':fila[6]
                    }
                    datos_consulta.append(dato)
                resultado= datos_consulta
        conn.close()
        return resultado
    
#imprimir gastos
    @staticmethod  
    def excel_pagos_realizados():
        conn = conectar_bd()
        resultado = [{'vacio': 'No hay datos'}]
        with conn.cursor() as cursor:
            cursor.execute("""
                                SELECT 
                                pm.id AS pago_id,
                                pm.total_gasto,
                                pm.fecha_registro,
                                pm.observacion,
                                tm.nombre_mantenimiento AS tipo_mantenimiento,
                                ue.nombre_unidad AS unidad_educativa
                            FROM pago_mantenimiento pm
                            JOIN atendimiento a ON pm.id_atendimiento = a.id
                            JOIN solicitud s ON a.id_solicitud = s.id
                            JOIN tipo_mantenimiento tm ON s.id_tipo_mantenimiento = tm.id
                            JOIN unidad_educativa ue ON s.id_unidad_educativa = ue.id
                            ORDER BY pm.fecha_registro ASC;
                           """)
            resultado_sql = cursor.fetchall()
            if resultado_sql:
                datos_consulta=[]
                for fila in resultado_sql:
                    dato = {
                        'pago_id': fila[0],
                        'total_gasto': fila[1],
                        'fecha_registro':fecha(fila[2]),
                        'observacion':fila[3],
                        'tipo_mantenimiento':fila[4],
                        'unidad_educativa':fila[5]
                    }
                    datos_consulta.append(dato)
                resultado= datos_consulta
        conn.close()
        return resultado
    
