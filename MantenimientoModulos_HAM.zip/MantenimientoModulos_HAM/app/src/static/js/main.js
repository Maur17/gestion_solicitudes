// Evento que permite cerrar pantalla emergente
window.addEventListener("DOMContentLoaded", (event) => {
    const cerrarBtn = document.getElementById('cerrar-btn');
    if (cerrarBtn) {
        cerrarBtn.addEventListener('click', function() {
            const popup = document.querySelector('.cont_pantalla_emergente main');
            const overlay = document.getElementById('popup-overlay');
            if (popup) popup.remove();
            if (overlay) overlay.style.display = 'none';
        });
    }
});

// Funcion para crear mensaje en la pantalla
function crearMensaje(titulo, mensaje, redireccion) {
    const contenedor = document.getElementById('mensaje');
    const overlay = document.getElementById('popup-overlay');
    
    // Verifica si el contenedor ya tiene algún mensaje
    if (contenedor.children.length > 0) {
        return; // Si ya hay un mensaje, no hace nada
    }

    const popup = document.createElement('div');
    popup.classList.add('popup', titulo);
    
    const popupTitulo = document.createElement('h2');
    popupTitulo.textContent = titulo;
    
    const popupMensaje = document.createElement('p');
    popupMensaje.textContent = mensaje;
    
    const closeButton = document.createElement('button');
    closeButton.textContent = 'Cerrar';
    closeButton.classList.add('close-btn');
    
    closeButton.addEventListener('click', function() {
        popup.remove();
        overlay.style.display = 'none';
        if (redireccion) {
            window.location.href = redireccion;
        }
    });

    popup.append(popupTitulo, popupMensaje, closeButton);
    contenedor.append(popup);
    overlay.style.display = 'block';
}