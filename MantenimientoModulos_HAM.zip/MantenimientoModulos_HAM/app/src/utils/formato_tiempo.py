
def fecha_hora(tiempo):
    return tiempo.strftime('%d-%m-%Y %H:%M')

def fecha_hora_javascript(tiempo):
    return tiempo.strftime('%Y-%m-%dT%H:%M:%S')

def fecha(tiempo):
    return tiempo.strftime('%d-%m-%Y')