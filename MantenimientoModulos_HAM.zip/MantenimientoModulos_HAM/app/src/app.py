from flask import Flask
from flask_mysqldb import MySQL

#configuracion
from config.general import ConfigDesarrollo

# rutas de Modulos

from modulos.login.login_route import rt_login
from modulos.solicitudes.solicitudes_route import rt_solicitudes
from modulos.atendimientos.atendimientos_route import rt_atendimientos
from modulos.pago_mantenimiento.pago_mantenimiento_route import rt_pago_mantenimiento
from modulos.reportes.reportes_route import rt_reporte

app = Flask(__name__)

if __name__ == '__main__':
    # cargar configuraciones
    app.config.from_object(ConfigDesarrollo)
    # iniciar la BD
    inicio_mysql = MySQL(app)
    # blueprints
    app.register_blueprint(rt_login, url_prefix='/')
    app.register_blueprint(rt_solicitudes, url_prefix='/solicitudes')
    app.register_blueprint(rt_atendimientos, url_prefix='/atendimientos')
    app.register_blueprint(rt_pago_mantenimiento, url_prefix='/pago_mantenimiento')
    app.register_blueprint(rt_reporte, url_prefix='/reportes')

    # Ejecutar el servidor
    app.run(port=5000)