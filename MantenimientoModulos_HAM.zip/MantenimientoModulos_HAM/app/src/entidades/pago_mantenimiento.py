class Pago_Mantenimiento:
    def __init__(self, id=None, total_gasto=None, fecha_registro=None,adjunto_pago=None, observacion=None, id_atendimiento=None):
        self.id = id
        self.total_gasto = total_gasto
        self.fecha_registro = fecha_registro
        self.adjunto_pago = adjunto_pago
        self.observacion = observacion
        self.id_atendimiento = id_atendimiento

    def convertir_JSON(self):
        return {
            'id': self.id,
            'total_gasto': self.total_gasto,
            'fecha_registro': self.fecha_registro,
            'observacion': self.observacion,
            'id_atendimiento': self.id_atendimiento
        }