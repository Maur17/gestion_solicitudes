class Atendimiento:
    def __init__(self, id=None, fecha_registro=None, fecha_inicializacion=None, fecha_finalizacion=None, tarifa_servicio_empresa=None, tarifa_materiales=None, estado=None, id_empresa_contratada=None, id_solicitud=None):
        self.id = id
        self.fecha_registro = fecha_registro
        self.fecha_inicializacion = fecha_inicializacion
        self.fecha_finalizacion = fecha_finalizacion
        self.tarifa_servicio_empresa = tarifa_servicio_empresa
        self.tarifa_materiales = tarifa_materiales
        self.estado = estado
        self.id_empresa_contratada = id_empresa_contratada
        self.id_solicitud = id_solicitud

    def convertir_JSON(self):
        return {
            'id': self.id,
            'fecha_registro': self.fecha_registro,
            'fecha_inicializacion': self.fecha_inicializacion,
            'fecha_finalizacion': self.fecha_finalizacion,
            'tarifa_servicio_empresa': self.tarifa_servicio_empresa,
            'tarifa_materiales': self.tarifa_materiales,
            'estado': self.estado,
            'id_empresa_contratada': self.id_empresa_contratada,
            'id_solicitud': self.id_solicitud
        }

class Atendimiento_Cancelado:
    def __init__(self, id=None, fecha_registro=None, motivo=None, id_atendimiento=None):
        self.id = id
        self.fecha_registro = fecha_registro
        self.motivo = motivo
        self.id_atendimiento = id_atendimiento

    def convertir_JSON(self):
        return {
            'id': self.id,
            'fecha_registro': self.fecha_registro,
            'motivo': self.motivo,
            'id_atendimiento': self.id_atendimiento
        }