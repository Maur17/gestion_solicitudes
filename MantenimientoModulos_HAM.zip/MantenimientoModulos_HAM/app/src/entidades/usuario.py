class Usuario:
    def __init__(self, id = None, usuario=None, password=None, estado=None, id_rol=None, id_persona=None):
        self.id = id
        self.usuario = usuario
        self.password = password
        self.estado = estado
        self.id_rol = id_rol
        self.id_persona = id_persona

    def convertir_JSON(self):
        return {
            'id': self.id,
            'usuario': self.usuario,
            'password': self.password,
            'estado': self.estado,
            'id_rol': self.id_rol,
            'id_persona': self.id_persona
        }

class Rol:
    def __init__(self, id=None, nombre=None, descripcion=None):
        self.id = id
        self.nombre = nombre
        self.descripcion = descripcion

    def convertir_JSON(self):
        return {
            'id': self.id,
            'nombre': self.nombre,
            'descripcion': self.descripcion
        }
    

class Persona:
    def __init__(self, id=None, nombres=None, p_apellido=None, s_apellido=None, carnet=None, telefono=None):
        self.id = id
        self.nombres = nombres
        self.p_apellido = p_apellido
        self.s_apellido = s_apellido
        self.carnet = carnet
        self.telefono = telefono
        
        

    def convertir_JSON(self):
        return {
            'id': self.id,
            'nombres': self.nombres,
            'p_apellido': self.p_apellido,
            's_apellido': self.s_apellido,
            'carnet': self.carnet,
            'telefono': self.telefono,
            
        }
    