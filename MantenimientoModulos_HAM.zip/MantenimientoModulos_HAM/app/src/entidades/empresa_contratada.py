class Empresa_Contratada:
    def __init__(self, id=None, nombre_empresa=None, nit=None, direccion=None, estado=None):
        self.id = id
        self.nombre_empresa = nombre_empresa
        self.nit = nit
        self.direccion = direccion
        self.estado = estado

    def convertir_JSON(self):
        return {
            'id': self.id,
            'nombre_empresa': self.nombre_empresa,
            'nit': self.nit,
            'direccion': self.direccion,
            'estado': self.estado
        }

class Empresa_Mantenimiento:
    def __init__(self, id_tipo_mantenimiento=None, id_empresa_contratada=None, estado=None):
        self.id_tipo_mantenimiento = id_tipo_mantenimiento
        self.id_empresa_contratada = id_empresa_contratada
        self.estado = estado

    def convertir_JSON(self):
        return {
            'id_tipo_mantenimiento': self.id_tipo_mantenimiento,
            'id_empresa_contratada': self.id_empresa_contratada,
            'estado': self.estado
        }
    