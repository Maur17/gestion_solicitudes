
class Unidad_Educativa:
    def __init__(self, id=None, nombre_unidad=None, estado=None, direccion=None, id_unidad_vecinal=None):
        self.id = id
        self.nombre_unidad = nombre_unidad
        self.estado = estado
        self.direccion = direccion
        self.id_unidad_vecinal = id_unidad_vecinal

    def convertir_JSON(self):
        return {
            'id': self.id,
            'nombre_unidad': self.nombre_unidad,
            'estado': self.estado,
            'direccion': self.direccion,
            'id_unidad_vecinal': self.id_unidad_vecinal
        }
    
class Unidad_Vecinal:
    def __init__(self, id=None, numero_uv=None):
        self.id = id
        self.numero_uv = numero_uv

    def convertir_JSON(self):
        return {
            'id': self.id,
            'numero_uv': self.numero_uv
        }
