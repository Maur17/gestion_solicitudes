class Solicitud:
    def __init__(self, id=None, descripcion=None, fecha_registro=None, estado=None, id_tipo_mantenimiento=None, id_unidad_educativa=None):
        self.id = id
        self.descripcion = descripcion
        self.fecha_registro = fecha_registro
        self.estado = estado
        self.id_tipo_mantenimiento = id_tipo_mantenimiento
        self.id_unidad_educativa = id_unidad_educativa

    def convertir_JSON(self):
        return {
            'id': self.id,
            'descripcion': self.descripcion,
            'fecha_registro': self.fecha_registro,
            'estado': self.estado,
            'id_tipo_mantenimiento': self.id_tipo_mantenimiento,
            'id_unidad_educativa': self.id_unidad_educativa
        }
    
class Tipo_Mantenimiento:
    def __init__(self, id=None, nombre_mantenimiento=None, descripcion=None, estado=None, tarifa_estimada=None):
        self.id = id
        self.nombre_mantenimiento = nombre_mantenimiento
        self.descripcion = descripcion
        self.estado = estado
        self.tarifa_estimada = tarifa_estimada

    def convertir_JSON(self):
        return {
            'id': self.id,
            'nombre_mantenimiento': self.nombre_mantenimiento,
            'descripcion': self.descripcion,
            'estado': self.estado,
            'tarifa_estimada':self.tarifa_estimada
        }
